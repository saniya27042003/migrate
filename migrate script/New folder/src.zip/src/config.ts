// version: "3"
// services:
//   instamiligram_db:
//     image: "postgres:11"
//     container_name: "instamiligram_db"
//     ports:
//       - "54321:5432"
//     environment:
//       POSTGRES_PASSWORD: 'kunal'
