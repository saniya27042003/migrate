import { TypeOrmModuleOptions } from '@nestjs/typeorm';
export const config: TypeOrmModuleOptions = {
  type: 'postgres',
  // username: 'postgres',
  // password: 'shubhangi',
  // host: '127.0.0.1',
  // port: 5432,
  // username: 'bankuser', //bhairavnath username
  // password: 'bank@bhairavnath', //bhairavnath password
  // host: '139.59.63.215',
  // database: 'venkatesh',
  // username: 'dbuser', //bhairavnath username
  // password: 'dbuser@compserv', //bhairavnath password
  // host: '103.174.87.104',

  // username: 'postgres', //sidhanerli username
  // password: '123456', //sidhanerli password
  // port: 5432,
  // host: '192.168.1.131',
  // database: 'KUMAVAT',

  // database: 'testpargaonnew',
    // database: 'datta_pargaon',
    // database: 'SS_KOTOLI',
        // database: 'testpargaon',
        // type: 'postgres',

        username: 'dbuser', //sidhanerli username
        password: 'dbuser@compserv', //sidhanerli password
        port: 5432,
        host: '82.112.235.98',
        database: 'AACHARYASHREE',


  synchronize: false,
  // synchronize: true,
  logging: false,
  // logging: true,
  entities: ['dist/**/*.entity{.ts,.js}'],
  migrations: ["dist/migration/*{.ts,.js}"],
  cli: {
    migrationsDir: 'src/migration'
  },
};