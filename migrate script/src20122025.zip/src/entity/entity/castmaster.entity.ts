import { Column, Entity, Generated, PrimaryGeneratedColumn } from 'typeorm';

@Entity()
export class CAST_MASTER {

    @PrimaryGeneratedColumn()
    Cast_id: number

    @Column()
    Religion_id: string

    @Column()
    Cast: string

    @Column()
    Cast_EN: string

    @Column()
    Category_id: number

}
