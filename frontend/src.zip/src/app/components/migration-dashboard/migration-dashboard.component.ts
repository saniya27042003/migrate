import { Component, OnInit } from '@angular/core';
import { MigrationService } from 'src/app/services/migration.service';

@Component({
  selector: 'app-migration-dashboard',
  templateUrl: './migration-dashboard.component.html',
  styleUrls: ['./migration-dashboard.component.css']
})
export class MigrationDashboardComponent implements OnInit {

  // 1. Fixed "Core Entities" (Primary Buttons)
  coreTables = ['IDMASTER', 'LNMASTER', 'PGMASTER'];

  // 2. Map of who depends on whom
  dependencyMap: { [key: string]: string[] } = {
    'IDMASTER': ['OCCUPATIONMASTER', 'CASTMASTER', 'RISKCATEGORYMASTER', 'CUSTOMERADDRESS'],
    'LNMASTER': ['AUTHORITYMASTER', 'RECOVERYCLEARKMASTER', 'PRIORITYMASTER', 'WEAKERMASTER', 'PURPOSEMASTER', 'INDUSTRYMASTER', 'HEALTHMASTER', 'DIRECTORMASTER'],
    'PGMASTER': ['TDRECEIPTMASTER']
  };

  selectedParent: string | null = null;

  constructor(private migrationService: MigrationService) { }

  ngOnInit(): void { }

  selectPrimary(parent: string) {
    this.selectedParent = parent;
  }

  startMigration(tableName: string) {
    this.migrationService.migrateTable(tableName).subscribe({
      next: () => alert(`${tableName} migration successful!`),
      error: (err) => alert(`Error: ${err.message}`)
    });
  }
}