import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MigrationService {
  private baseUrl = 'http://localhost:7272/migrate';

  constructor(private http: HttpClient) { }

  // This is the function the component is looking for
  migrateTable(tableName: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/${tableName}`, {});
  }
}
